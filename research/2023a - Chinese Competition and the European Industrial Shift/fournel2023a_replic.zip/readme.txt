
Replication files for Fournel-2023a:

https://github.com/andyf66/acad_main/blob/main/research/2023a%20-%20Chinese%20Competition%20and%20the%20European%20Industrial%20Shift/repl_2023a

fournel2023a_main_ze: selection of labour market outcomes per employment zones (INSEE's zones d'emploi, ZE-2010 definition), plus several major SES controls, plus the index of exposure to import competition from several key partners (underlying data: INSEE-Census, INSEE-EE, Comtrade) 

fournel2023a_main_ze: idem, tech file for robustness exercise of Goldsmith et alii-2021

fournel2023a_manufempl: structure of the local industrial employment using NACE-38 classification (INSEE-Census) at the ZE-2010 level